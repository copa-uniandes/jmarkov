# jmarkov
jMarkov is a library to simplify the modeling of systems with Markov chains.
