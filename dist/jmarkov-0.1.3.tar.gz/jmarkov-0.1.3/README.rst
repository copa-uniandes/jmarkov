jMarkov
=======

*jMarkov* is a Python library to simplify the modeling of systems with Markov chains.